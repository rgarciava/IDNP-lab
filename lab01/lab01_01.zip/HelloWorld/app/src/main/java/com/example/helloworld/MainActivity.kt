package com.example.helloworld

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.helloworld.ui.theme.HelloWorldTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            HelloWorldTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->

                    RegistroLibro(
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }

    private fun guardarRegistro(
        titulo: String,
        autor: String,
        paginas: String
    ) {

        val contenido = """
            
            -------------------------
            Título: $titulo
            Autor: $autor
            Páginas leídas: $paginas
            -------------------------
        """.trimIndent()

        openFileOutput(
            "registro_libro.txt",
            MODE_APPEND
        ).use {
            it.write(contenido.toByteArray())
        }

        Log.d(
            "LIBRO",
            "Registro guardado:\n$contenido"
        )
    }

    private fun leerRegistro(): String {

        return try {

            openFileInput("registro_libro.txt")
                .bufferedReader()
                .use {
                    it.readText()
                }

        } catch (e: Exception) {

            "No existe ningún registro guardado."
        }
    }

    @Composable
    fun RegistroLibro(
        modifier: Modifier = Modifier
    ) {

        var titulo by remember {
            mutableStateOf("")
        }

        var autor by remember {
            mutableStateOf("")
        }

        var paginas by remember {
            mutableStateOf("")
        }

        var registroLeido by remember {
            mutableStateOf("")
        }

        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(24.dp),

            verticalArrangement = Arrangement.Center
        ) {

            Text(
                text = "Registro de libro"
            )

            Spacer(
                modifier = Modifier.height(20.dp)
            )

            OutlinedTextField(
                value = titulo,

                onValueChange = {
                    titulo = it
                },

                label = {
                    Text("Título del libro")
                },

                modifier = Modifier.fillMaxWidth()
            )

            Spacer(
                modifier = Modifier.height(12.dp)
            )

            OutlinedTextField(
                value = autor,

                onValueChange = {
                    autor = it
                },

                label = {
                    Text("Autor")
                },

                modifier = Modifier.fillMaxWidth()
            )

            Spacer(
                modifier = Modifier.height(12.dp)
            )

            OutlinedTextField(
                value = paginas,

                onValueChange = {
                    paginas = it
                },

                label = {
                    Text("Número de páginas leídas")
                },

                modifier = Modifier.fillMaxWidth()
            )

            Spacer(
                modifier = Modifier.height(20.dp)
            )

            Button(
                onClick = {

                    guardarRegistro(
                        titulo = titulo,
                        autor = autor,
                        paginas = paginas
                    )

                    titulo = ""
                    autor = ""
                    paginas = ""
                },

                modifier = Modifier.fillMaxWidth()
            ) {

                Text("Guardar")
            }

            Spacer(
                modifier = Modifier.height(12.dp)
            )

            Button(
                onClick = {

                    registroLeido = leerRegistro()

                    Log.d(
                        "LIBRO",
                        "TODOS LOS REGISTROS:\n$registroLeido"
                    )

                    println(
                        "TODOS LOS REGISTROS:\n$registroLeido"
                    )
                },

                modifier = Modifier.fillMaxWidth()
            ) {

                Text("Ver registro")
            }

            Spacer(
                modifier = Modifier.height(20.dp)
            )

            if (registroLeido.isNotEmpty()) {

                Text(
                    text = registroLeido
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun RegistroLibroPreview() {

    HelloWorldTheme {

        Text(
            text = "Registro de libro"
        )
    }
}