package com.example.navcompose_loginregistro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.navcompose_loginregistro.ui.theme.NavCompose_LoginRegistroTheme
import java.net.URLDecoder
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        crearCuentaInicial()

        setContent {
            NavCompose_LoginRegistroTheme {

                val navController = rememberNavController()

                NavHost(
                    navController = navController,
                    startDestination = "login"
                ) {

                    composable("login") { backStackEntry ->

                        val mensajeRegistro =
                            backStackEntry.savedStateHandle
                                .get<String>("mensajeRegistro")

                        LoginScreen(
                            mensajeRegistro = mensajeRegistro,

                            onLoginExitoso = { usuario ->

                                val usuarioCodificado =
                                    URLEncoder.encode(
                                        usuario,
                                        StandardCharsets.UTF_8.toString()
                                    )

                                navController.navigate(
                                    "home/$usuarioCodificado"
                                )
                            },

                            onIrARegistro = {
                                navController.navigate("registro")
                            }
                        )
                    }

                    composable("registro") {

                        RegistroScreen(

                            onRegistroExitoso = {

                                navController.previousBackStackEntry
                                    ?.savedStateHandle
                                    ?.set(
                                        "mensajeRegistro",
                                        "Cuenta registrada correctamente"
                                    )

                                navController.popBackStack()
                            },

                            onCancelar = {
                                navController.popBackStack()
                            }
                        )
                    }

                    composable(
                        route = "home/{usuario}",
                        arguments = listOf(
                            navArgument("usuario") {
                                type = NavType.StringType
                            }
                        )
                    ) { backStackEntry ->

                        val usuarioCodificado =
                            backStackEntry.arguments
                                ?.getString("usuario")
                                ?: ""

                        val usuario =
                            URLDecoder.decode(
                                usuarioCodificado,
                                StandardCharsets.UTF_8.toString()
                            )

                        HomeScreen(usuario = usuario)
                    }
                }
            }
        }
    }

    private fun crearCuentaInicial() {

        val cuentas = leerCuentas()

        val existeAdmin = cuentas.any {
            it.first == "admin"
        }

        if (!existeAdmin) {

            openFileOutput(
                "cuentas.txt",
                MODE_APPEND
            ).use { archivo ->

                archivo.write(
                    "admin|1234\n".toByteArray()
                )
            }
        }
    }

    private fun leerCuentas(): List<Pair<String, String>> {

        return try {

            openFileInput("cuentas.txt")
                .bufferedReader()
                .useLines { lineas ->

                    lineas.mapNotNull { linea ->

                        val partes = linea.split("|")

                        if (partes.size == 2) {
                            partes[0] to partes[1]
                        } else {
                            null
                        }

                    }.toList()
                }

        } catch (e: Exception) {

            emptyList()
        }
    }

    private fun verificarCuenta(
        usuario: String,
        password: String
    ): Boolean {

        val cuentas = leerCuentas()

        return cuentas.any {
            it.first == usuario &&
                    it.second == password
        }
    }

    private fun guardarCuenta(
        usuario: String,
        password: String
    ) {

        openFileOutput(
            "cuentas.txt",
            MODE_APPEND
        ).use { archivo ->

            archivo.write(
                "$usuario|$password\n".toByteArray()
            )
        }
    }

    @Composable
    fun LoginScreen(
        mensajeRegistro: String?,
        onLoginExitoso: (String) -> Unit,
        onIrARegistro: () -> Unit
    ) {

        var usuario by remember {
            mutableStateOf("")
        }

        var password by remember {
            mutableStateOf("")
        }

        var mensajeError by remember {
            mutableStateOf("")
        }

        var mensajeExito by remember {
            mutableStateOf(mensajeRegistro ?: "")
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),

            verticalArrangement = Arrangement.Center
        ) {

            Text(
                text = "Iniciar sesión",
                style = MaterialTheme.typography.headlineSmall
            )

            Spacer(
                modifier = Modifier.height(16.dp)
            )

            OutlinedTextField(
                value = usuario,

                onValueChange = {
                    usuario = it
                    mensajeError = ""
                },

                label = {
                    Text("Usuario")
                },

                modifier = Modifier.fillMaxWidth()
            )

            Spacer(
                modifier = Modifier.height(8.dp)
            )

            OutlinedTextField(
                value = password,

                onValueChange = {
                    password = it
                    mensajeError = ""
                },

                label = {
                    Text("Contraseña")
                },

                visualTransformation =
                    PasswordVisualTransformation(),

                modifier = Modifier.fillMaxWidth()
            )

            Spacer(
                modifier = Modifier.height(16.dp)
            )

            if (mensajeExito.isNotEmpty()) {

                Text(
                    text = mensajeExito,
                    color = MaterialTheme.colorScheme.primary
                )

                Spacer(
                    modifier = Modifier.height(8.dp)
                )
            }

            if (mensajeError.isNotEmpty()) {

                Text(
                    text = mensajeError,
                    color = MaterialTheme.colorScheme.error
                )

                Spacer(
                    modifier = Modifier.height(8.dp)
                )
            }

            Button(
                onClick = {

                    if (
                        usuario.isBlank() ||
                        password.isBlank()
                    ) {

                        mensajeError =
                            "Complete todos los campos"

                        mensajeExito = ""

                    } else {

                        val existe =
                            verificarCuenta(
                                usuario,
                                password
                            )

                        if (existe) {

                            mensajeError = ""
                            mensajeExito = ""

                            onLoginExitoso(usuario)

                        } else {

                            mensajeError =
                                "Cuenta no encontrada"

                            mensajeExito = ""
                        }
                    }
                },

                modifier = Modifier.fillMaxWidth()
            ) {

                Text("Ingresar")
            }

            Spacer(
                modifier = Modifier.height(8.dp)
            )

            OutlinedButton(
                onClick = onIrARegistro,

                modifier = Modifier.fillMaxWidth()
            ) {

                Text("Crear cuenta")
            }
        }
    }

    @Composable
    fun RegistroScreen(
        onRegistroExitoso: () -> Unit,
        onCancelar: () -> Unit
    ) {

        var usuario by remember {
            mutableStateOf("")
        }

        var password by remember {
            mutableStateOf("")
        }

        var mensajeError by remember {
            mutableStateOf("")
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),

            verticalArrangement = Arrangement.Center
        ) {

            Text(
                text = "Crear cuenta",
                style = MaterialTheme.typography.headlineSmall
            )

            Spacer(
                modifier = Modifier.height(16.dp)
            )

            OutlinedTextField(
                value = usuario,

                onValueChange = {
                    usuario = it
                    mensajeError = ""
                },

                label = {
                    Text("Nuevo usuario")
                },

                modifier = Modifier.fillMaxWidth()
            )

            Spacer(
                modifier = Modifier.height(8.dp)
            )

            OutlinedTextField(
                value = password,

                onValueChange = {
                    password = it
                    mensajeError = ""
                },

                label = {
                    Text("Nueva contraseña")
                },

                visualTransformation =
                    PasswordVisualTransformation(),

                modifier = Modifier.fillMaxWidth()
            )

            Spacer(
                modifier = Modifier.height(16.dp)
            )

            if (mensajeError.isNotEmpty()) {

                Text(
                    text = mensajeError,
                    color = MaterialTheme.colorScheme.error
                )

                Spacer(
                    modifier = Modifier.height(8.dp)
                )
            }

            Button(
                onClick = {

                    if (
                        usuario.isBlank() ||
                        password.isBlank()
                    ) {

                        mensajeError =
                            "Complete todos los campos"

                    } else {

                        guardarCuenta(
                            usuario.trim(),
                            password
                        )

                        onRegistroExitoso()
                    }
                },

                modifier = Modifier.fillMaxWidth()
            ) {

                Text("Aceptar")
            }

            Spacer(
                modifier = Modifier.height(8.dp)
            )

            OutlinedButton(
                onClick = onCancelar,

                modifier = Modifier.fillMaxWidth()
            ) {

                Text("Cancelar")
            }
        }
    }

    @Composable
    fun HomeScreen(
        usuario: String
    ) {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),

            verticalArrangement = Arrangement.Center
        ) {

            Text(
                text = "Bienvenido $usuario",

                style = MaterialTheme.typography.headlineMedium
            )

            Spacer(
                modifier = Modifier.height(16.dp)
            )

            Text(
                text = "Has iniciado sesión correctamente."
            )
        }
    }
}